package com.fri.chmelar.app

import com.fri.chmelar.view.MainView
import tornadofx.*

class MyApp: App(MainView::class, Styles::class)